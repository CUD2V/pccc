Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, for FY2017 (36,875 codes).
POAexemptCodes2017.xlsx (Excel spreadsheet)
POAexemptCodes2017.txt (tab delimited text)
These files have three fields, as below.
Order2017: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file, for FY2017.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2017 POA exempt list, from the previous list, to properly match the guidelines (1817 codes).
POAexemptAddCodes2017.xlsx (Excel spreadsheet)
POAexemptAddCodes2017.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been added to the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2017 POA exempt list (178 codes).
POAexemptDeleteCodes2017.xlsx (Excel spreadsheet)
POAexemptDeleteCodes2017.txt (tab delimited text)
These files have two fields, as below.
POAexemptCode: the ICD-10-CM code that has been removed from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes revised from the previous POA exempt list, to create the current FY2017 POA exempt list (174 codes, each twice as Revise from and Revise to, for 348 lines).
POAexemptReviseCodes2017.xlsx (Excel spreadsheet)
POAexemptReviseCodes2017.txt (tab delimited text)
These files have three fields, as below.
Action: "Revise from" and "Revise to" showing the previous title and the new title, respectively.
POAexemptCode: the ICD-10-CM code that has been revised from the previous list.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
